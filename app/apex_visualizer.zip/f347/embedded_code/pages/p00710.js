// --------------------------------------------------------------------------------
// 
// Oracle APEX source export file
// 
// The contents of this file are intended for review and analysis purposes only.
// Developers must use the Application Builder to make modifications to an
// application. Changes to this file will not be reflected in the application.
// 
// --------------------------------------------------------------------------------

// ----------------------------------------
// Page: 710 - APEX 22.2 > Dynamic Action: change P0_APP_ID - refresh regions > Action: NATIVE_JAVASCRIPT_CODE > Settings > Code

av_refresh_hide_show_regions()

// ----------------------------------------
// Page: 710 - APEX 22.2 > Dynamic Action: click refresh - refresh regions > Action: NATIVE_JAVASCRIPT_CODE > Settings > Code

av_refresh_hide_show_regions()

