prompt --application/shared_components/navigation/lists/desktop_navigation_bar
begin
--   Manifest
--     LIST: Desktop Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.5'
,p_default_workspace_id=>100001
,p_default_application_id=>347
,p_default_id_offset=>20408574139881448
,p_default_owner=>'APEX_VISUALIZER'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(472901013601347796)
,p_name=>'Desktop Navigation Bar'
,p_static_id=>'desktop-navigation-bar'
,p_version_scn=>'1'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(472901155879347802)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Log Out'
,p_static_id=>'log-out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
