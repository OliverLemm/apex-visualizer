prompt --application/shared_components/user_interface/lovs/pages
begin
--   Manifest
--     PAGES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.4'
,p_default_workspace_id=>100001
,p_default_application_id=>347
,p_default_id_offset=>20408574139881448
,p_default_owner=>'APEX_VISUALIZER'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(469958774571399192)
,p_lov_name=>'PAGES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  page_name || '' ('' || page_id || '')'' page,',
'       page_id ',
'  from apex_application_pages',
'where application_id = :P0_APP_ID',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
